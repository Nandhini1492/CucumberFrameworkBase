package com.sarvatra.test.Project_name.Stepdefination;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.qa.util.CommonFunctions;
import com.qa.util.DriverFactory;
import com.project.test.Projectname.pageobjects.HomePage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class HomePageStep {

	public CommonFunctions cf = new CommonFunctions(DriverFactory.driver);
	private HomePage homePage = new HomePage(DriverFactory.driver);
	public SoftAssert sa = new SoftAssert();

	Logger log = (Logger) LogManager.getLogger("LoginPageTest.java");

	/**
	 * ####################- @author mayur_kale -###########################
	 */
	@Then("User logged in as {string}")
	public void user_logged_in_as(String string) {
		log.info("User Logged in as: " + string);
		Assert.assertEquals(homePage.getUserNameAfterLogin(), string, "Logged in as: " + string);
	}

	@Given("User is on Homepage")
	public void user_is_on_homepage() {
		log.info("User is on HomePage");
		Assert.assertTrue(homePage.verifyUserIsOnHomePage());
	}

	/*
	 * Operations on Configurations Menu
	 */
	/**
	 * ####################- @author mayur_kale -###########################
	 */
	@When("Click on Entities in Configurations Menu")
	public void click_on_entities_in_configurations_menu() {
		log.info("Clicked on Entities in Configurations Menu");
		Assert.assertTrue(homePage.clickOnEntitiesIcon());
		cf.waitforSometime(1000);
	}

	@When("Click on Users in Configurations Menu")
	public void Click_on_Users_in_Configurations_Menu() {
		log.info("Clicked on Users in Configurations Menu");
		Assert.assertTrue(homePage.clickOnUserIcon());
	}

	/*
	 * Operations on Left hand side - menu's
	 */
	/**
	 * ####################- @author mayur_kale -###########################
	 */
	@Then("Click on logout button")
	public void click_on_logout_button() {
		log.info("Click on logout button");
		Assert.assertTrue(homePage.clickOnLogOut());
	}

	/**
	 * ####################- @author sriharo_kovvuri -###########################
	 */
	@Then("Verify leftHand side menu configurations having Entities")
	public void Verify_leftHand_side_menu_configurations_having_Entities() {
		log.info("verify the left hand menu entities in Configurations Menu");
		Assert.assertTrue(homePage.entities_LeftMenu());
	}

	@Then("Verify leftHand side menu configurations having Users")
	public void Verify_leftHand_side_menu_configurations_having_Users() {
		log.info("verify the left hand menu entities in Configurations Menu");
		Assert.assertTrue(homePage.users_leftMenu());
	}

	@And("Verify lefthand side menu showing reports and changepassword options")
	public void Verify_lefthand_side_menu_showing_reports_and_changepassword_options() {
		Assert.assertTrue(homePage.reports());
		Assert.assertTrue(homePage.changePassword());
	}

	@When("Click on Reports in right hand side main menu on issuing bank admin login page")
	public void Click_on_Reports_in_right_hand_side_main_menu_on_issuing_bank_admin_login_page() {
		Assert.assertTrue(homePage.clickReports());
	}

	/**
	 * ####################- @author amol_kale -###########################
	 */
	
	// Login With Admin user

	@When("Click on Reports in left-hand side main menu on issuing bank admin login page")
	public void click_on_reports_in_left_hand_side_main_menu_on_issuing_bank_admin_login_page() {
		log.info("Click on Reports in left-hand side main menu on issuing bank admin login page");
		homePage.clickOnReportOnHP();
	}

	@Then("verify user should navigate to Reports Configuration screen")
	public void verify_user_should_navigate_to_reports_configuration_screen() {
		log.info("verify user should navigate to Reports Configuration screen");
		Assert.assertEquals(homePage.verifyReportPageDisplayed(), "Reports Configuration");
	}
	
	@When("Click on Configuration in left-hand side main menu and verify view Entities and User submenu")
    public void click_on_configuration_in_left_hand_side_main_menu_and_verify_view_entities_and_user_submenu() {
        log.info(
                "Click on Configuration in left-hand side main menu and verify view Entities and User submenu");
        Assert.assertTrue(homePage.ClickConfigButtonOnLHSAndVerifySubmenu());
    }

	@Then("Click on Entities in Configuration on left-hand side main menu and verify user should be navigated to View Entity Details page")
	public void click_on_entities_in_configuration_on_left_hand_side_main_menu_and_verify_user_should_be_navigated_to_view_entity_details_page() {
		log.info(
				"Click on Entities in Configuration on left-hand side main menu and verify user should be navigated to View Entity Details page");
		Assert.assertEquals(homePage.ClickEntityButtonOnLHSAndVerifyEntityPage(), "View Entity Details");
	}

	@Then("Click on User in Configuration on left-hand side main menu and verify user should be navigated to User Management page")
	public void click_on_user_in_configuration_on_left_hand_side_main_menu_and_verify_user_should_be_navigated_to_user_management_page() {
		log.info(
				"Click on User in Configuration on left-hand side main menu and verify user should be navigated to User Management page");
		Assert.assertEquals(homePage.ClickUserButtonOnLHSAndVerifyUserPage(), "User Management");
	}

	@Then("Verify that user should be navigate to Login page")
	public void verify_that_user_should_be_navigate_to_login_page() {
		log.info("Verify that user should be navigate to Login page");
	}
	
	@Then("Verify user can see Entities & Users in Configurations Menu on Home screen.")
	public void verify_user_can_see_entities_users_in_configurations_menu_on_home_screen() {
		log.info("Verify user can see Entities & Users in Configurations Menu on Home screen.");
		Assert.assertTrue(homePage.verifySubMenuOfConfigMenu());
		
	}
	
	
	@Then("Verify that Admin user can view Display Name {string} and Date & Time tag in right corner side on header")
	public void verify_that_admin_user_can_view_display_name_and_date_time_tag_in_right_corner_side_on_header(String string) {
		log.info("Verify that Admin user can view Display Name {string} and Date & Time tag in right corner side on header");
		Assert.assertEquals(homePage.verifyDisplayNameAndLastLoginTag(), string);
	}
	
	@Then("Verify that the user should view select report dropdown on Reports Configuration page")
	public void verify_that_the_user_should_view_select_report_dropdown_on_reports_configuration_page() {
		log.info("Verify that the user should view select report dropdown on Reports Configuration page");
		Assert.assertTrue(homePage.clickReports());

	}
	
	

}
