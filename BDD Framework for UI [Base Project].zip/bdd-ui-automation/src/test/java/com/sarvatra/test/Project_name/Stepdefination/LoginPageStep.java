package com.sarvatra.test.Project_name.Stepdefination;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import com.qa.util.CommonFunctions;
import com.qa.util.DriverFactory;
import com.project.test.Projectname.pageobjects.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPageStep {

	public CommonFunctions cf = new CommonFunctions(DriverFactory.driver);
	private LoginPage loginPage = new LoginPage(DriverFactory.driver);
	public SoftAssert sa = new SoftAssert();

	Logger log = (Logger) LogManager.getLogger("LoginPageTest.java");

	/**
	 * ####################- @author mayur_kale -###########################
	 */
	@Given("User is on LoginPage")
	public void user_is_on_login_page() {
		log.info("User is on LoginPage: " + loginPage.loginPageTitle());
		Assert.assertEquals(loginPage.loginPageTitle(), "Sarvatra e-HUB");
	}

	@When("Enter the UserNM {string} and Pass {string} and click on LOGIN as {string}")
	public void enter_the_user_nm_and_pass_and_click_on_login(String string, String string2, String string3) {
		log.info("User successfully login - User is on Home Page");
		Assert.assertEquals(loginPage.userLogin(string, string2), string3);
	}

}
