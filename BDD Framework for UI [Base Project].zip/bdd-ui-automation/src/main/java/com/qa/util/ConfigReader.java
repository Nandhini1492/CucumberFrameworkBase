package com.qa.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;




/*import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;*/


public class ConfigReader {

	
	  private Properties prop;
	  
	 /**
		 * This method is used to load the properties from config.properties file
		 * 
		 * @return it returns Properties prop object
		 */
			  public Properties init_prop() {
			  
			  prop = new Properties(); try { FileInputStream ip = new
			  FileInputStream("./src/test/resources/config/config.properties");
			  prop.load(ip);
			  
			  } catch (FileNotFoundException e) { e.printStackTrace(); } catch (IOException
			  e) { e.printStackTrace(); }
			  
			  return prop;
			  
			  }
			 
	
	
	/*
	 * public static Properties prop = new Properties();
	 * 
	 * private static String propFileName
	 * =("./src/test/resources/config/config.properties");
	 * 
	 * 
	 * 
	 * public static void loadPropValues() throws IOException {
	 * 
	 * prop = new Properties(); InputStream inputStream =
	 * ConfigReader.class.getClassLoader().getResourceAsStream(propFileName);
	 * 
	 * if (inputStream != null) { prop.load(inputStream); }else { throw new
	 * FileNotFoundException("property file '" + propFileName +
	 * "' not found in the classpath"); }
	 * 
	 * }
	 */
}
