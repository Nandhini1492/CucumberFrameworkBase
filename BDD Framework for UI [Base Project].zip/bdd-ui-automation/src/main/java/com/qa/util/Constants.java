package com.qa.util;


public class Constants extends DriverFactory{
	
	public static long PAGE_LOAD_TIMEOUT = 40;
	public static long IMPLICIT_WAIT = 40;


}
