package com.project.test.Projectname.pageobjects;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.qa.util.CommonFunctions;

public class LoginPage {

	private WebDriver driver;
	private WebDriverWait wait;
	CommonFunctions c;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 1), this);
		c = new CommonFunctions(driver);
	}
	/*
	 * ####################- Created/Updated by --> Mayur_Kale -###########################
	 * 
	 */	
	
// #Elements on Top-Right-Corner Section on HomePage
	@FindBy(xpath = "//div[@style='text-align: right;']//div[@class='ng-binding']")
	@CacheLookup
	WebElement userNameText;

// #Elements On Login Page - Login Window
	@FindBy(xpath = "//input[@id='userName']")
	@CacheLookup
	WebElement userNameInputBox;

	@FindBy(xpath = "//input[@id='password']")
	@CacheLookup
	WebElement passwordInputBox;

	@FindBy(xpath = "//button[contains(text(),'Log in')]")
	@CacheLookup
	WebElement logInButton;

	@FindBy(xpath = "//button[contains(text(),'Forgot Password')]")
	@CacheLookup
	WebElement forgoatPasswordButton;

// #Elements On Confirmation Pop-Up Window
	@FindBy(xpath = "//md-dialog[@aria-label='Confirm Login']")
	@CacheLookup
	WebElement confirmLoginPopup;

	@FindBy(xpath = "//button[@class='md-primary md-confirm-button md-button md-ink-ripple md-default-theme md-focused'][contains(.,'Yes')]")
	@CacheLookup
	WebElement confirmLoginPopupYes;
	
	
	@FindBy(xpath = "//span[contains(text(),'Invalid Username or Password')]")
	@CacheLookup
	WebElement invalidmessage;
	
 
	/*
	 * #######################- Created/Updated by - Mayur_Kale -##############################
	 * 
	 */
	
	public String loginPageTitle() {
		c.waitforSometime(1500);
		return driver.getTitle();
	}

	public boolean userNameTextBox() {
		wait.until(ExpectedConditions.visibilityOf(userNameInputBox));
		return  userNameInputBox.isDisplayed();
	}

	public boolean passwordTextBox() {
		wait.until(ExpectedConditions.visibilityOf(passwordInputBox));
		return passwordInputBox.isDisplayed();
	}

	public String userLogin(String usrName, String password) {
		wait.until(ExpectedConditions.visibilityOf(userNameInputBox));
		userNameInputBox.clear();
		userNameInputBox.sendKeys(usrName);

		wait.until(ExpectedConditions.visibilityOf(passwordInputBox));
		passwordInputBox.clear();
		passwordInputBox.sendKeys(password);
		
		wait.until(ExpectedConditions.visibilityOf(logInButton));
		logInButton.click();
		c.waitforSometime(1000);

		try {
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			confirmLoginPopupYes.click();

		} catch (Exception e) {
			System.out.println("Confirmation Login Pop-up not displayed");
		}

		wait.until(ExpectedConditions.visibilityOf(userNameText));
		System.out.println("After login verify:- "+userNameText.getText());
		return userNameText.getText();
	}

	public void forgotPasswordButton() {
		wait.until(ExpectedConditions.visibilityOf(forgoatPasswordButton));
		forgoatPasswordButton.click();
	}

	
	public void InvaliduserLogin(String usrName, String password) {
		wait.until(ExpectedConditions.visibilityOf(userNameInputBox));
		userNameInputBox.clear();
		userNameInputBox.sendKeys(usrName);

		wait.until(ExpectedConditions.visibilityOf(passwordInputBox));
		passwordInputBox.clear();
		passwordInputBox.sendKeys(password);
		
		wait.until(ExpectedConditions.visibilityOf(logInButton));
		logInButton.click();
		c.waitforSometime(1000);
		
		try {
			wait.until(ExpectedConditions.visibilityOf(invalidmessage));
			String message=invalidmessage.getText();
			System.out.println(message);
		
		
	} catch (Exception e) {
		System.out.println("message not displayed");
	}

	
		
		
	}
}	
	
	

