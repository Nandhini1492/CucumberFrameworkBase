package com.project.test.Projectname.pageobjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.util.CommonFunctions;

public class HomePage {
	/*
	 * #######################- Created/Updated by --> Mayur_Kale#############
	 * 
	 */
	private WebDriver driver;
	private WebDriverWait wait;
	CommonFunctions cf;
	LoginPage lp;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 1), this);
		cf = new CommonFunctions(driver);
		lp = new LoginPage(driver);
	}

// #Elements on Top-Right-Corner Section

	@FindBy(xpath = "//div[@style='text-align: right;']//div[@class='ng-binding']")
	@CacheLookup
	WebElement userNameText;

// #Elements in Left-Side Bar Section

	@FindBy(xpath = "//md-sidenav[@md-component-id='left']//md-toolbar/*")
	@CacheLookup
	WebElement sarvatraEhubIcon;

	@FindBy(xpath = "//button[@aria-label='Logout']")
	@CacheLookup
	WebElement logout;
	
	@FindBy(xpath = "//div[@class='ng-binding ng-scope']")
	@CacheLookup
	WebElement LastLoginTag;

// #Elements in Bharat BillPay Section

	@FindBy(xpath = "//tr[@check-module='BBPS']//label[contains(.,'Transaction History')]")
	@CacheLookup
	WebElement bbpsTxnHistory;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement bbpsWalletStatement;

// #Elements in Sarvatra ATM Section

	@FindBy(xpath = "//tr[@check-module='SRVT_MN_ATM']//label[contains(.,'Transaction History')]")
	@CacheLookup
	WebElement miniatmTxnHistory;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement miniatmBulkUpload;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement miniatmSettlementReport;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement miniatmMerchantOnboard;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement miniatmReconDashboard;

// #Elements in microATM Section

	@FindBy(xpath = "//tr[@check-module='MICRO_ATM']//label[contains(.,'Transaction History')]")
	@CacheLookup
	WebElement microatmTxnHistory;

	@FindBy(xpath = "//tr[@check-module='MICRO_ATM']//label[contains(.,'BulkUpload')]")
	@CacheLookup
	WebElement microatmBulkUpload;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement miniatmReconData;

	@FindBy(xpath = "")
	@CacheLookup
	WebElement microatmReconDashboard;

// #Elements in Configurations Section

	@FindBy(xpath = "//div[@role='button'][contains(.,'Entities')]//md-icon")
	@CacheLookup
	WebElement entitiesIcon;

	@FindBy(xpath = "//div[@role='button'][contains(.,'Services')]")
	@CacheLookup
	WebElement servicesIcon;

	@FindBy(xpath = "//div[@role='button'][contains(.,'Channels')]")
	@CacheLookup
	WebElement channelsIcon;

	@FindBy(xpath = "//div[@role='button'][contains(.,'Users')]")
	@CacheLookup
	WebElement usersIcon;

	@FindBy(xpath = "//div[@role='button'][contains(.,'System Conf')]")
	@CacheLookup
	WebElement sysstemConfigIcon;

	@FindBy(xpath = "//div[@role='button'][contains(.,'Migration')]")
	@CacheLookup
	WebElement migrationIcon;

// #Elements on Other Page (View Entity Details Page)

	@FindBy(xpath = "//h2[contains(text(),'View Entity Details')]")
	@CacheLookup
	WebElement entityDetailsTitle;

	/*
	 * ####################- Created/Updated by --> Srihari_Kovvuri ################
	 * 
	 */
	@FindBy(xpath = "//h2[contains(text(),'User Management')]")
	@CacheLookup
	WebElement UserManagementDetailsTitle;

	@FindBy(xpath = "//button[@aria-label='Entities']")
	WebElement EntitiesLMenu;

	@FindBy(xpath = "//button[@aria-label='Users']")
	WebElement UsersLMenu;

	@FindBy(xpath = "//div//button[@aria-label='Reports']")
	WebElement ReportsMenu;

	@FindBy(xpath = "//div//button[@aria-label='Change Password']")
	WebElement ChangePasswordMenu;

	@FindBy(xpath = "//div//span[@class='bgwhite' and contains(text(),'Configurations')]")
	WebElement ConfigurationLMenu;

	@FindBy(xpath = "//label[contains(text(),'Select a Report')]")
	WebElement reportdropdown;

	/*
	 * #######################- Created/Updated by --> Amol_Kale ##################
	 *
	 */
// login with admin user
	@FindBy(xpath = "//div/button[@aria-label='Reports']")
	@CacheLookup
	WebElement ClickOnReports;

	@FindBy(xpath = "//div/h2[contains(.,'Reports Configuration')]")
	@CacheLookup
	WebElement ReportPage;

	@FindBy(xpath = "//div/span[contains(.,\"Configurations\")]")
	@CacheLookup
	WebElement ConfigButton;

	@FindBy(xpath = "//div/button[@aria-label='Users']")
	@CacheLookup
	WebElement UserOnLHS;

	@FindBy(xpath = "//div/button[@aria-label='Entities']")
	@CacheLookup
	WebElement EntityOnLHS;

	@FindBy(xpath = "//div/h2[contains(.,'View Entity Details')]")
	@CacheLookup
	WebElement EntityPageDisplayed;

	@FindBy(xpath = "//div/h2[contains(.,'User Management')]")
	@CacheLookup
	WebElement UserMangPageDisplayed;

	@FindBy(xpath = "//div/button[contains(.,'Log in')]")
	@CacheLookup
	WebElement LoginPageDisplayed;

	/*
	 * #######################- Created/Updated by --> Mayur_Kale ##################
	 * 
	 */

	// #Configurations Section
	public boolean clickOnEntitiesIcon() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(entitiesIcon));
			entitiesIcon.click();
		} catch (Exception e) {
			cf.waitforSometime(2500);
			entitiesIcon.click();
		}
		wait.until(ExpectedConditions.visibilityOf(entityDetailsTitle));
		return entityDetailsTitle.isDisplayed();
	}

	public boolean clickOnUserIcon() {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(usersIcon));
			usersIcon.click();
		} catch (Exception e) {
			cf.waitforSometime(3000);
			usersIcon.click();
		}
		wait.until(ExpectedConditions.visibilityOf(UserManagementDetailsTitle));
		return UserManagementDetailsTitle.isDisplayed();
	}

	// #Left-Side Menu Bar Section

	public boolean clickOnLogOut() {
		try {
			cf.waitforSometime(500);
			logout.click();
			return true;
		} catch (Exception e) {
			try {
				driver.close();
				driver.switchTo().window(driver.getWindowHandle());
				cf.waitforSometime(500);
				logout.click();
				return true;
			} catch (Exception f) {
				try {
					cf.switchSeleniumFocusWindow(1);
					cf.waitforSometime(500);
					logout.click();
					return true;
				} catch (Exception g) {
					return false;
				}
			}
		}
	}

	public String getUserNameAfterLogin() {
		wait.until(ExpectedConditions.visibilityOf(userNameText));
		return userNameText.getText();
	}

	public boolean verifyUserIsOnHomePage() {
		wait.until(ExpectedConditions.visibilityOf(entitiesIcon));
		return entitiesIcon.isDisplayed();
	}

	public boolean clickOnSarvatraEhubIcon() {
		sarvatraEhubIcon.click();
		wait.until(ExpectedConditions.visibilityOf(entitiesIcon));
		return entitiesIcon.isDisplayed();
	}

	/*
	 *############- Created/Updated by --> Srihari_Kovvuri -########
	 * 
	 */
	public boolean entities_LeftMenu() {
		boolean flag = EntitiesLMenu.isDisplayed();
		if (flag == false) {
			ConfigurationLMenu.isDisplayed();
			ConfigurationLMenu.click();
			boolean flag1 = EntitiesLMenu.isDisplayed();
			return flag1;
		} else {
			return true;
		}
	}

	public boolean users_leftMenu() {
		boolean flag = UsersLMenu.isDisplayed();
		if (flag == false) {
			ConfigurationLMenu.isDisplayed();
			ConfigurationLMenu.click();
			boolean flag1 = UsersLMenu.isDisplayed();
			return flag1;
		} else {
			return true;
		}
	}

	public boolean reports() {
		cf.waitforSometime(1500);
		return ReportsMenu.isDisplayed();
	}

	public boolean changePassword() {
		cf.waitforSometime(1500);
		return ChangePasswordMenu.isDisplayed();
	}

	public boolean clickReports() {
		try {
			ReportsMenu.click();
			cf.waitForElementTobeVisible(reportdropdown);
			cf.waitforSometime(1000);
			return reportdropdown.isDisplayed();
			
		} catch (Exception e) {
			try {
				ReportsMenu.click();
				cf.waitForElementTobeVisible(reportdropdown);
				cf.waitforSometime(1000);
				return reportdropdown.isDisplayed();
				
			} catch (Exception c) {
				c.printStackTrace();
				return false;
			}
		}
		
	}

	public void clickChangePassword() {
		ChangePasswordMenu.click();
		cf.waitforSometime(1500);
	}

	/*
	 * ####################- Created/Updated by --> AMol_Kale #################
	 *
	 */
	public void clickOnReportOnHP() {
		ClickOnReports.click();
	}

	public String verifyReportPageDisplayed() {
		return ReportPage.getText();
	}

	public boolean ClickConfigButtonOnLHSAndVerifySubmenu() {
		wait.until(ExpectedConditions.visibilityOf(ConfigButton));
		ConfigButton.click();
		EntityOnLHS.isDisplayed();
		UserOnLHS.isDisplayed();
		return true;
	}

	public String ClickEntityButtonOnLHSAndVerifyEntityPage() {
		wait.until(ExpectedConditions.visibilityOf(EntityOnLHS));
		EntityOnLHS.click();
		return EntityPageDisplayed.getText();
	}

	public String ClickUserButtonOnLHSAndVerifyUserPage() {
		wait.until(ExpectedConditions.visibilityOf(UserOnLHS));
		UserOnLHS.click();
		return UserMangPageDisplayed.getText();
	}
	
	public boolean verifySubMenuOfConfigMenu() {
		wait.until(ExpectedConditions.visibilityOf(entitiesIcon));
		entitiesIcon.isDisplayed();
		wait.until(ExpectedConditions.visibilityOf(usersIcon));
		usersIcon.isDisplayed();
		return true;
	}
	
	public String verifyDisplayNameAndLastLoginTag() {
		wait.until(ExpectedConditions.visibilityOf(userNameText));
		userNameText.isDisplayed();
		LastLoginTag.isDisplayed();
		return userNameText.getText();
	}


}
